from django.contrib import admin
from .models import Courses, Lesson

admin.site.register(Courses)
admin.site.register(Lesson)