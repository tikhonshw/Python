from django.db import models


class Course(models.Model):
    # slug, title, desc, image
    slug = models.SlugField('Уникальное название курса')
    title = models.CharField('Название курса', max_length=120)
    desc = models.TextField('Описание курса')
    image = models.ImageField('Изображение', default='default.png', upload_to='course_images')

    def __str__(self):
        return self.title

