from django.shortcuts import render
from .models import Film
from .serializers import FilmSerializer
from rest_framework.viewsets import ModelViewSet


class FilmsViewSet(ModelViewSet):
    queryset = Film.objects.all()
    serializer_class = FilmSerializer
