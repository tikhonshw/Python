from django.contrib import admin
from django.urls import path
from rest_framework.routers import SimpleRouter

from .views import FilmsViewSet

router = SimpleRouter()
router.register('api/films', FilmsViewSet)

urlpatterns = [

]

urlpatterns += router.urls
