<script>
import axios from 'axios';

export default {
    data() {
        return {
            films: []
        }
    },
    async mounted() {
        try {
            const res = await axios.get('http://127.0.0.1:8000/api/films/?format=json');
            this.films = res.data;
        } catch(error) {
            console.log(error);
        }

    }
}
</script>

<template>
    <h1>Страница с фильмами</h1>
    <div class="film" v-for="film, i in films" :key="i">
        <h3>{{ film.title }}</h3> 
        <p>Цена: {{ film.price }}</p>
    </div>
</template>

<style>
@import './assets/base.css';

h1 {
    margin-top: 50px;
    text-align: center;
}

.film {
    background: #242424;
    padding: 20px;
    display: inline-block;
    margin: 20px;
}
</style>
