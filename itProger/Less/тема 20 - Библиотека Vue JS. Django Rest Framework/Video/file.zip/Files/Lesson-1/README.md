To install the project run in the terminal:
npm install
