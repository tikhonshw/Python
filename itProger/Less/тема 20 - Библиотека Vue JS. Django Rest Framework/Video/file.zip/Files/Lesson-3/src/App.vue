<template>
  <div v-if="num < 3 || isVisible">
    <h1>Hello</h1>
    <p>Hello</p>
  </div>
  <div v-else-if="num == 3">Second block</div>
  <div v-else>Last block</div>
  <input @input="this.num = $event.target.value" /><br /><br />
  <button @click="this.isVisible = !this.isVisible">Скрыть/показать</button>
  <div v-if="isVisible">Text 1</div>
  <div v-show="isVisible">Text 2</div>

  <!-- <p>{{ books[1].author }}</p> -->
  <ul>
    <li v-for="(el, index) in books" v-bind:key="index">
      {{ index + 1 }} – {{ el.name }} - <b>{{ el.author }}</b> /
      <em>{{ el.genre }}</em>
    </li>
  </ul>
</template>

<script>
export default {
  data() {
    return {
      num: 4,
      isVisible: true,
      books: [
        { name: "1984", author: "Джордж Оруэлл", genre: "Роман" },
        {
          name: "Собака Баскервилей",
          author: "Артур Коннан Дойл",
          genre: "Детектив",
        },
        { name: "Гарри Поттер", author: "Джоан Роулинг", genre: "Роман" },
      ],
    };
  },
};
</script>

<style>
</style>