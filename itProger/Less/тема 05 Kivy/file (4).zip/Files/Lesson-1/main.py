from kivy.app import App
from kivy.uix.button import Button
from kivy.uix.boxlayout import BoxLayout

class DuckyApp(App):
    def build(self):
        box = BoxLayout()
        b1 = Button(text="Привет всем")
        box.add_widget(b1)
        box.add_widget(Button(text="Привет всем 2"))
        return box

if __name__ == "__main__":
    DuckyApp().run()