from django.contrib import admin
from .models import News, Feedback

admin.site.register(News)
admin.site.register(Feedback)


# Register your models here.
