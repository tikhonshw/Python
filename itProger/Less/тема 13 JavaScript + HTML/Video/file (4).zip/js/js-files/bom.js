// console.log(window.innerHeight);
// window.open("https://itproger.com/rights", "hello", "width=500,height=400");

// console.log(navigator.platform);

// setTimeout(function() {
//   location.reload();
// }, 2000);

// location.href = "https://itproger.com";
