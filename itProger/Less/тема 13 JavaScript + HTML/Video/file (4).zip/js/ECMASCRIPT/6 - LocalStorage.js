localStorage.setItem("name", "Alex")
console.log(localStorage.getItem("name"))

// localStorage.clear()
// localStorage.removeItem("name")
console.log(localStorage.key(0))