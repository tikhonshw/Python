class Info {
  users = ["Alex", "Bob", "John"];

  info(param) {
    console.log(param);
  }
}

export default Info;

// export const users = ["Alex", "Bob", "John"];
//
// export function info(param) {
//   console.log(param);
// }
