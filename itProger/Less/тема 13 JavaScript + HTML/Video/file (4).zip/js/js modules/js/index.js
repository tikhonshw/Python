import Some from './info.js';

let info = new Some();
info.info(info.users);
