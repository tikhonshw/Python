let myFirstVar = false;
var mySecondVar = "Hello World";
mySecondVar = "Hello";

let num = 45;
var nothing = undefined;

let number = 47;
number = 45;

let num_2 = 5;

const Number = 34;

// console.log("Переменная: " + Number);
