for(var i = 0; i < 10; i++)
  console.log(i);

console.log("");

console.log(i);

// let arr = [5, 6, "Hello", 's', true, 9];
//
// arr.forEach(function(item, i, array) {
//   console.log("Элемент под номером №" + i + ": " + item + ". Массив: " + array);
// });
//
// for(var key in arr) {
//   console.log("Элемент под номером №" + key + ": " + arr[key]);
// }

// for(var i = 0; i < arr.length; i++)
//   console.log("Элемент под номером №" + (i + 1) + ": " + arr[i]);
//
// console.log("");
//
// var i = 0;
// while(i < arr.length) {
//   console.log("Элемент под номером №" + (i + 1) + ": " + arr[i]);
//   i++;
// }

// for(var i = 1; i < 20; i++) {
//   if(i > 15)
//     break;
//
//   if(i % 2 != 0)
//     continue;
//
//   console.log(i);
// }

// let hasCar = true;
//
// while(hasCar) {
//   console.log("Yes");
//
//   if(!hasCar)
//     break;
// }

// var i = 100;
// do {
//   console.log(i);
//   i++;
// } while(i < 10);
