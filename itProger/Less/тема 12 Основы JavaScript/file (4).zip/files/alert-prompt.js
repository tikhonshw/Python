// var numbers = 45;
// alert("Переменная: " + numbers);

// let getUserInfo = prompt("Сколько вам лет?", 18);
// alert("Переменная: " + getUserInfo);

let isConfirm = confirm("Согласны ли вы на обработку данных?");
alert(isConfirm);
