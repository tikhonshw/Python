let x = 56;
let y = 10;
let res;

res = x + y;
console.log("Результат: " + res);
res = x - y;
console.log("Результат: " + res);

res = x * y;
console.log("Результат: " + res);

res = x / y;
console.log("Результат: " + res);

res = x % y;
console.log("Результат: " + res);

res += 10;
console.log("Результат: " + res);

res--;
console.log("Результат: " + res);

res = -res;
console.log("Результат: " + res);

res = y - ++res;
console.log("Результат: " + res);

let str = "Hello ";
let str_2 = "World";
console.log("Результат: " + (str + str_2));
