# import pytesseract
# pytesseract.pytesseract.tesseract_cmd = 'C:\Program Files\Tesseract-OCR\tesseract.exe'

from PIL import Image
from pytesseract import image_to_string

text = image_to_string(Image.open('images/russian.png'), lang="rus")
print(text)