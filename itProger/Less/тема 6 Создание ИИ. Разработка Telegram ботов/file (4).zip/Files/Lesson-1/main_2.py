import pyttsx3
import speech_recognition as sr
import datetime
import webbrowser

engine = pyttsx3.init()

def sayToMe(talk):
    engine.say(talk)
    engine.runAndWait()

sayToMe("Привет всем! У нас все работает отлично")
sayToMe("Скажите хоть что-то")

record = sr.Recognizer()
try:
    with sr.Microphone(device_index=0) as source:
        print("Говори..")
        audio = record. listen(source)

        result = record.recognize_google(audio, language="ru—RU")
        result = result.lower()
        print(result)

        if result == "скажи время":
            now = datetime.datetime.now()
            str_date = "Сейчас {}:{}".format(str(now.hour), str(now.minute))
            print(str_date)
            sayToMe(str_date)
        elif result == "открой веб-сайт":
            webbrowser.open("https://itproger.com")


except sr.UnknownValueError:
    print("Голос был не распознан")
except sr.RequestError:
    print("Что-то пошло не так")